#pragma once
#include "Node.h"
#include <iostream>

#ifndef BST_H
#define BST_H

template <class T>
class BST
{
public:
	BST() { root = NULL; }
	void insert(T data);
	void showTree(Node<T>* aux, int cont);
	void deleteNode(T data);
	void childs(Node<T>* node);
	void isEmpty();
	T Ancestors(T data);
	T whatLevelamI(T data);
	T Height();
    void insertNode(T data);
    void show();
    void clearBST();

private:
	Node<T>* root;
};

template<class T>
void BST<T>::insert(T data)
{
	Nodew<T>* auxNew = new Node<T>(data);
	if (root == NULL)
	{
		root = auxNew;
	}
	else
	{
		Node<T>* auxFather = root;
		bool inserted = false;
		while (!inserted)
		{
			if (data < auxFather->getData())
			{
				if (auxPAdre->getLeft() == NULL)
				{
					auxFather->setLeft(auxNew);
					inserted = true;
				}
				else
				{
					auxFathe r = auxFather->getLeft();
				}
			}
			else
			{
				if (auxFather->getRight() == NULL)
				{
					auxFather->setRight(auxNew);
					inserted = true;
				}
				else
				{
					auxFather = auxFather->getRight();
				}
			}
		}
	}
}

template <class T>
void BST<T>::clearBST() {
    root = NULL;
}

template<class T>
void BST<T>::showTree(Node<T>* aux, int cont) 
{
	if(aux==NULL)
	{
		return;
	}
	else
	{
		showTree(aux->getRight(), cont + 1);
	}
	for(int i=0; i<cont; i++)
	{
		cout << " ";
	}
	cout << aux->getData() << endl;
	showTree(aux->getLeft(), cont + 1);
}

template<class T>
void BST<T>::childs(Node<T>* node)
{
	int numChilds = 0;
	if (node->getLeft() != NULL)
	{
		numChilds++;
	}
	if (node->getRight() != NULL)
	{
		numChilds++;
	}
	return numChilds;
}

template<class T>
void BST<T>::isEmpty()
{
	return root == NULL;
}
template <class T>
void BST<T>::show() {
    int cont = 0;
    cout << endl;
    showTree(root, cont);
    cout << endl;
}


template<class T>
void BST<T>::insertNode(T data) {
    Node<T>* auxNew = new Node<T>(data);
    if (isEmpty()) {
        root = auxNew;
    }
    else {
        Node<T>* auxFather = root;
        bool inserted = false;
        while (!inserted) {
            if (data < auxFather->getData()) {
                if (auxFather->getLeft() == NULL) {
                    auxFather->setLeft(auxNew);
                    inserted = true;
                }
                else {
                    auxFather = auxFather->getLeft();
                }
            }
            else {
                if (auxFather->getRight() == NULL) {
                    auxFather->setRight(auxNew);
                    inserted = true;
                }
                else {
                    auxFather = auxFather->getRight();
                }
            }
        }
    }
}

template<class T>
void BST<T>::deleteNode(T data) {
    if (!isEmpty()) {
        Node<T>* aux = root;
        if (root->getData() == data) { // Valor buscado igual al valor de root
            switch (childs(root)) {
            case 0: // Root no tiene hijos
            {
                root = NULL;
                delete aux;
                break;
            }
            case 1: // Root tiene 1 hijo
            {
                (root->getLeft() == NULL) ? root = root->getRight() : root = root->getRight();
                delete aux;
                break;
            }
            case 2: // Root tiene 2 hijos
            {
                Node<T>* aux2 = root->getLeft();
                if (aux2->getRight() == NULL) {
                    T data = aux2->getData();
                    deleteNode(aux2->getData());
                    aux->setData(data);
                }
                else {
                    aux2 = aux2->getRight();
                    while (aux2->getRight() != NULL) {
                        aux2 = aux2->getRight();
                    }
                    T data = aux2->getData();
                    deleteNode(aux2->getData());
                    root->setData(data);
                }
                break;
            }
            default:
                break;
            }
        }
        else {
            bool deleted = false;
            while (!deleted) {
                if (data < aux->getData()) {
                    //Valor buscado menor al valor del auxiliar
                    if (aux->getLeft() == NULL) {
                        deleted = true;
                    }
                    else {
                        if (data == aux->getLeft()->getData()) {
                            cout << "Childs: " << childs(aux->getLeft()) << endl;
                            switch (childs(aux->getLeft())) {
                            case 0: // No tiene hijos
                            {
                                cout << "No tiene hijos" << endl;
                                Node<T>* aux2 = aux->getLeft();
                                aux->setLeft(NULL);
                                delete aux2;
                                break;
                            }
                            case 1: // Root tiene 1 hijo
                            {
                                cout << "Tiene 1 hijo" << endl;
                                Node<T>* aux2 = aux->getLeft();
                                (aux2->getLeft() == NULL) ? aux->setLeft(aux2->getRight()) : aux->setLeft(aux2->getLeft());
                                delete aux2;
                                break;
                            }
                            case 2: // Root tiene 2 hijos
                            {
                                Node<T>* aux2 = aux->getLeft();
                                if (aux2->getLeft()->getRight() == NULL) {
                                    T data = aux2->getLeft()->getData();
                                    deleteNode(aux2->getLeft()->getData());
                                    aux->getLeft()->setData(data);
                                }
                                else {
                                    aux2 = aux2->getLeft();
                                    while (aux2->getRight() != NULL) {
                                        aux2 = aux2->getRight();
                                    }
                                    T data = aux2->getData();
                                    deleteNode(aux2->getData());
                                    aux->getLeft()->setData(data);
                                }
                                break;
                            }
                            default:
                                break;
                            }
                            deleted = true;
                        }
                        else {  // no es igual
                            aux = aux->getLeft();
                        }
                    }
                }
                else {  // es mayor o igual
                 //Valor buscado es mayor o igual al valor del auxiliar
                    if (aux->getRight() == NULL) {
                        deleted = true;
                    }
                    else {
                        if (data == aux->getRight()->getData()) {
                            switch (childs(aux->getRight())) {
                            case 0: // No tiene hijos
                            {
                                Node<T>* aux2 = aux->getRight();
                                aux->setRight(NULL);
                                delete aux2;
                                break;
                            }
                            case 1: // Root tiene 1 hijo
                            {
                                Node<T>* aux2 = aux->getRight();
                                (aux2->getLeft() == NULL) ? aux->setRight(aux2->getRight()) : aux->setRight(aux2->getLeft());
                                delete aux2;
                                break;
                            }
                            case 2: // Root tiene 2 hijos
                            {
                                Node<T>* aux2 = aux->getRight();
                                if (aux2->getLeft()->getRight() == NULL) {
                                    T data = aux2->getLeft()->getData();
                                    deleteNode(aux2->getLeft()->getData());
                                    aux->setData(data);
                                }
                                else {
                                    aux2 = aux2->getLeft();
                                    while (aux2->getRight() != NULL) {
                                        aux2 = aux2->getRight();
                                    }
                                    T data = aux2->getData();
                                    deleteNode(aux2->getData());
                                    aux->getRight()->setData(data);
                                }
                                break;
                            }
                            default:
                                break;
                            }
                            deleted = true;
                        }
                        else {  // no es igual
                            aux = aux->getRight();
                        }
                    }
                }
            }
        }
    }
}

template<class T>
T BST<T>::Ancestors(T data)
{
	T father;
	Node<T>* aux = root;
	while (!isEmpty()) {
		if (aux->getData() != data) {
			father.push_back(aux->getData());
			aux = (aux->getData() > data) ? aux->getLeft() : aux->getRight();
		}
		else {
			return father;
		}
	}
	return father;
}

template<class T>
T BST<T>::whatLevelamI(T data) {
	T count = 0;
	Node<T>* aux = root;
	while (!isEmpty()) {
		if (aux->getData() == data) {
			return count;
		}
		aux = (aux->getData() > data ? aux->getLeft() : aux->getRight());
		count += 1;
	}
	return -1;
}

template<class T>
T BST<T>::Height()
{
	T cont = 1;
	if (!isEmpty)
	{
		int left = height(root->getLeft());
		int right = height(root->getRight());
		cont += max(izquierda, derecha);
	}
	else {
		cont = 0;
	}
	return cont;
}

#endif // !BST_H
