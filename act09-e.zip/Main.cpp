#include<iostream>
#include<string>

using namespace std;

#include "BST.h"

int main() {

    BST<int> bst;
    int valor;

    bst.insertNode(10);
    bst.insertNode(16);
    bst.insertNode(6);
    bst.insertNode(8);
    bst.insertNode(4);
    bst.insertNode(5);
    bst.insertNode(2);
    bst.show();


    int opc = 0;
    while (opc != 5) {

        cout << "1) Agregar Nodo" << endl;
        cout << "2) Eliminar Nodo" << endl;
        cout << "3) Imprimir BST" << endl;
        cout << "4) Limpiar arbol" << endl;
        cout << "5) Salir" << endl;
        cout << endl;
        cout << "Teclea la opci�n deseada: " << endl;
        cin >> opc;
        cout << endl;

        switch (opc)
        {
        case 1:
            printf("\033c");
            cout << "Ingresa el valor entero que deseas agregar al BST" << endl;
            cin >> valor;
            bst.insertNode(valor);
            bst.show();
            break;
        case 2:
            printf("\033c");
            cout << "Ingresa el valor entero que deseas eliminar en el BST" << endl;
            cin >> valor;
            bst.deleteNode(valor);
            bst.show();
            break;
        case 3:
            bst.show();
        case 4:
            bst.clearBST();
            bst.show();
        default:
            break;
        }
    }

    return 0;

}