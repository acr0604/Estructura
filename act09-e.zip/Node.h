#pragma once
#include <iostream>
#ifndef Node_H
#define Node_H

template <class T>

class Node {
public:
	Node(T data);
	Node(T data, Node<T>* left, Node<T>* right);

	T getData() { return data; };
	Node<T>* getLeft() { return left; };
	Node<T>* getRight() { return right; };

	void setData(T data) { this->data = data; };
	void setLeft(Node<T>* left) { this->left = left; };
	void setRight(Node<T>* right) { this->right = right; };

private:
	T data;
	Node<T>* left;
	Node<T>* right;
};

template <class T>
Node<T> ::Node(T data) {
	this->data = data;
	this->left = NULL;
	this->right = NULL;
}

template <class T>
Node<T> ::Node(T data, Node<T>* left, Node<T>* right) {
	this->data = data;
	this->left = left;
	this->right = right;
}
#endif // !Node_H

