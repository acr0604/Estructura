#include<iostream>
#include<string>

using namespace std;

#include "BST.h"

int main() {

    BST<int> bst;
    int valor;

    bst.insertNode(10);
    bst.insertNode(16);
    bst.insertNode(6);
    bst.insertNode(8);
    bst.insertNode(4);
    bst.insertNode(5);
    bst.insertNode(2);
    bst.show();

    cout << "Ingresa el valor entero que deseas eliminar en el BST" << endl;
    cin >> valor;
    bst.deleteNode(valor);
    bst.show();
}


