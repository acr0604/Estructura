#ifndef ListaEncadenada_H
#define ListaEncadenada_H

#include "Nodo.h"

template <class LE>
class ListaEncadenada
{
public:
	ListaEncadenada();
	void AgregaUltimo(LE dato);
	void mostrarDatos();
	void ActualizaLista(LE dato, LE datoN);
	void BorrarTodo();
	bool BorrarDato(LE dato);
	bool LeerDato(LE dato);

private:
	Nodo<LE>* Cabeza;
	int Tamanio = 0;

};

template<class LE>
ListaEncadenada<LE>::ListaEncadenada()
{
	Cabeza = NULL;
	Tamanio = 0;
}

template<class LE>
void ListaEncadenada<LE>::AgregaUltimo(LE dato)
{
	Nodo<LE>* nodo = new Nodo<LE>(dato);
	if (Cabeza == NULL)
	{
		Cabeza = new Nodo<LE>(dato);
	}
	else
	{
		Nodo<LE>* aux = Cabeza;

		while (aux->getDatoS() != NULL)
		{
			aux = aux->getDatoS();
		}
		aux->setDatoS(nodo);
	}
	Tamanio++;
}

template<class LE>
void ListaEncadenada<LE>::mostrarDatos()
{
	Nodo<LE>* aux = Cabeza;
	int cont = 1;
	while (aux != NULL)
	{
		cout << "Dato " << cont << aux->getDato() << endl;
		aux = aux->getDatoS();
		cont++;
	}
}

template<class LE>
void ListaEncadenada<LE>::ActualizaLista(LE dato, LE datoN)
{
	Nodo<LE>* aux = Cabeza;
	if(aux->getDato == dato)
	{
		aux->getDato(datoN);
		return;
	}
	aux = aux->getDatoS();
}

template<class LE>
void ListaEncadenada<LE>::BorrarTodo()
{
	Nodo<LE>* aux = Cabeza;
	while(aux != NULL)
	{
		aux = aux->getDatoS();
		delete aux;
	}
}

template<class LE>
bool ListaEncadenada<LE>::BorrarDato(LE dato)
{
	Nodo<LE>* aux = Cabeza;
	if (aux->getDato() == dato)
	{
		Cabeza = aux->getDatoS();
		delete aux;
		Tamanio--;
		return true;
	}
	Nodo<LE>* aux2 = aux->getDatoS();

	while (aux2 != NULL)
	{
		if (aux2->getDato() == dato)
		{
			aux->setDatoS(aux2->getDatoS());
			delete aux2;
			Tamanio--;
			return true;
		}
		aux = aux2;
		aux2 = aux2->getDatoS();
	}
	return false;
}

template<class LE>
bool ListaEncadenada<LE>::LeerDato(LE dato)
{
	Nodo<LE>* aux = Cabeza;
	while(aux != NULL)
	{
		if(aux->getDato() == dato)
		{
			return true;
		}
		aux = aux->getDatoS();
	}
	return false;
}

#endif // !ListaEncadenada_H