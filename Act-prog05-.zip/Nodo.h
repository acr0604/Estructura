#ifndef Nodo_H
#define Nodo_H

template <class N>
class Nodo
{
public:
	Nodo(N Dato);
	Nodo(N Dato, N* DatoS);
	N getDato();
	Nodo<N>* getDatoS();
	void setDato(N Dato);
	void setDatoS(Nodo<N>* DatoS);


private:
	N Dato;
	Nodo<N>* DatoS;
};

template<class N>
Nodo<N>::Nodo(N Dato)
{
	this->Dato = Dato;
	this->DatoS = NULL;
}

template<class N>
Nodo<N>::Nodo(N Dato, N* DatoS)
{
	this->Dato = Dato;
	this->DatoS = DatoS;
}

template<class N>
Nodo<N>* Nodo<N>::getDatoS()
{
	return this->DatoS;
}

template<class N>
N Nodo<N>::getDato()
{
	return this->Dato;
}

template<class N>
void Nodo<N>::setDato(N Dato)
{
	this->Dato = Dato;
}

template<class N>
void Nodo<N>::setDatoS(Nodo<N>* Dato)
{
	this->DatoS = DatoS;
}

#endif // !Nodo_H