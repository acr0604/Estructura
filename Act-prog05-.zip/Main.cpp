#pragma once
#include <iostream>
#include <string>
#include "ListaEncadenada.h"

using namespace std;

int main()
{
	ListaEncadenada<string> lista;

	lista.AgregaUltimo("Emma");
	lista.AgregaUltimo("Ricardo");
	lista.AgregaUltimo("Arturo");

	if(lista.LeerDato("Emma"))
	{
		cout << "Emma se encuentra en la lista" << endl;
	}
	else
	{
		cout << "Emma no se encuentra en la lista" << endl;
	}
	return 0;
}